#include "functions.h"

int add(int a, int b)
{
	return a+b;
}

int mult(int a, int b)
{
	return a*b;
}
