#include <stdio.h>
int main (int argc, char** argv)
{
	printf ("Muj login je xlogin00\n");
	return 0;
}
