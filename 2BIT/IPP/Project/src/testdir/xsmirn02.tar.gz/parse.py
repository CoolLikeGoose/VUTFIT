from parse_lib.parser import Parser

if __name__ == '__main__':
    parser = Parser()
    parser.process_code()