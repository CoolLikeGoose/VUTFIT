#include <stdio.h>
#include "functions.h"

int main()
{
	int a=5;
	int b=6;
	printf("%d + %d = %d\n",a,b,add(a,b));
	return 0;
}
