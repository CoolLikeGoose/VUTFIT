#ifndef FUNCTIONS
#define FUNCTIONS

int add(int a, int b);
int mult(int a, int b);
#endif
