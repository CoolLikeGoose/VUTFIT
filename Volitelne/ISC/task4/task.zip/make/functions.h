#ifndef FUNCTIONS
#define FUNCTIONS


int max(int arg[], int length);
int min (int arg[], int length);
int sum(int arg[], int length);

#endif
