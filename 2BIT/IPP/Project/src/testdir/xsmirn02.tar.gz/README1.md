# Implementační dokumentace k %cislo%. úloze do IPP 2023/2024 \
Jméno a příjmení: %jmeno_prijmeni%
Login: %xlogin99%